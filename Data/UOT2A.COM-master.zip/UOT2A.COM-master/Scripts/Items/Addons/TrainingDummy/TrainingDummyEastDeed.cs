namespace Server.Items
{
    public class TrainingDummyEastDeed : BaseAddonDeed
    {
        public override BaseAddon Addon{ get{ return new TrainingDummyEast(); } }
        public override int LabelNumber{ get{ return 1044335; } } // training dummy (east)

        [Constructable]
        public TrainingDummyEastDeed()
        {
        }

        public TrainingDummyEastDeed( Serial serial ) : base( serial )
        {
        }

        public override void Serialize( GenericWriter writer )
        {
            base.Serialize( writer );

            writer.Write( (int) 0 ); // version
        }

        public override void Deserialize( GenericReader reader )
        {
            base.Deserialize( reader );

            int version = reader.ReadInt();
        }
    }
}