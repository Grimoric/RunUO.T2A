namespace Server.Items
{
    public class TrainingDummySouth : BaseAddon
    {
        public override BaseAddonDeed Deed{ get{ return new TrainingDummySouthDeed(); } }

        [Constructable]
        public TrainingDummySouth()
        {
            AddComponent( new TrainingDummy( 0x1070 ), 0, 0, 0 );
        }

        public TrainingDummySouth( Serial serial ) : base( serial )
        {
        }

        public override void Serialize( GenericWriter writer )
        {
            base.Serialize( writer );

            writer.Write( (int) 0 ); // version
        }

        public override void Deserialize( GenericReader reader )
        {
            base.Deserialize( reader );

            int version = reader.ReadInt();
        }
    }
}