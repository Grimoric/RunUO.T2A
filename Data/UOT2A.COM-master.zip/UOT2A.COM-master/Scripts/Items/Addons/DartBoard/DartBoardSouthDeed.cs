namespace Server.Items
{
    public class DartBoardSouthDeed : BaseAddonDeed
    {
        public override BaseAddon Addon{ get{ return new DartBoardSouth(); } }

        public override int LabelNumber{ get{ return 1044325; } } // dartboard (south)

        [Constructable]
        public DartBoardSouthDeed()
        {
        }

        public DartBoardSouthDeed( Serial serial ) : base( serial )
        {
        }

        public override void Serialize( GenericWriter writer )
        {
            base.Serialize( writer );

            writer.WriteEncodedInt( 0 ); // version
        }

        public override void Deserialize( GenericReader reader )
        {
            base.Deserialize( reader );

            int version = reader.ReadEncodedInt();
        }
    }
}