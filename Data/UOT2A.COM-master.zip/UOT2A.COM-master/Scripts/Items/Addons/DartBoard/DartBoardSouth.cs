namespace Server.Items
{
    public class DartBoardSouth : BaseAddon
    {
        public override BaseAddonDeed Deed{ get{ return new DartBoardSouthDeed(); } }

        public DartBoardSouth()
        {
            AddComponent( new DartBoard( false ), 0, 0, 0 );
        }

        public DartBoardSouth( Serial serial ) : base( serial )
        {
        }

        public override void Serialize( GenericWriter writer )
        {
            base.Serialize( writer );

            writer.WriteEncodedInt( 0 ); // version
        }

        public override void Deserialize( GenericReader reader )
        {
            base.Deserialize( reader );

            int version = reader.ReadEncodedInt();
        }
    }
}