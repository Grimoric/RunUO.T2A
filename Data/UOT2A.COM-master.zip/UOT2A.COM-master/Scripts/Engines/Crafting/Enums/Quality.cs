﻿namespace Server.Items
{
    public enum Quality
    {
        Low,
        Regular,
        Exceptional
    }
}
